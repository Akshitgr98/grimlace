<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Shoes</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Photo-Hub Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Quicksand:300,400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
    <script type="text/javascript">
	    $(document).ready(function () {
	        $('#horizontalTab').easyResponsiveTabs({
	            type: 'default', //Types: default, vertical, accordion           
	            width: 'auto', //auto or any width like 600px
	            fit: true   // 100% fit in a container
	        });
	    });
    </script>	
<script src="js/menu_jquery.js"></script>    
</head>
<body>
<?php
if(isset($_POST["pic56"]))
	{
		session_start();
		$_SESSION["order"]="pic56";
		header("location:orderform.html");
	}
if(isset($_POST["pic55"]))
	{
		session_start();
		$_SESSION["order"]="pic55";
		header("location:orderform.html");
	}
if(isset($_POST["pic54"]))
	{
		session_start();
		$_SESSION["order"]="pic54";
		header("location:orderform.html");
	}
	if(isset($_POST["pic53"]))
	{
		session_start();
		$_SESSION["order"]="pic53";
		header("location:orderform.html");
	}
	if(isset($_POST["pic52"]))
	{
		session_start();
		$_SESSION["order"]="pic52";
		header("location:orderform.html");
	}
	if(isset($_POST["pic51"]))
	{
		session_start();
		$_SESSION["order"]="pic51";
		header("location:orderform.html");
	}
	if(isset($_POST["pic50"]))
	{
		session_start();
		$_SESSION["order"]="pic50";
		header("location:orderform.html");
	}
	if(isset($_POST["pic49"]))
	{
		session_start();
		$_SESSION["order"]="pic49";
		header("location:orderform.html");
	}
	if(isset($_POST["pic48"]))
	{
		session_start();
		$_SESSION["order"]="pic48";
		header("location:orderform.html");
	}
	if(isset($_POST["pic47"]))
	{
		session_start();
		$_SESSION["order"]="pic47";
		header("location:orderform.html");
	}
	if(isset($_POST["pic46"]))
	{
		session_start();
		$_SESSION["order"]="pic46";
		header("location:orderform.html");
	}
	if(isset($_POST["pic45"]))
	{
		session_start();
		$_SESSION["order"]="pic45";
		header("location:orderform.html");
	}
	if(isset($_POST["pic44"]))
	{
		session_start();
		$_SESSION["order"]="pic44";
		header("location:orderform.html");
	}
	if(isset($_POST["pic43"]))
	{
		session_start();
		$_SESSION["order"]="pic43";
		header("location:orderform.html");
	}
	if(isset($_POST["pic42"]))
	{
		session_start();
		$_SESSION["order"]="pic42";
		header("location:orderform.html");
	}
	if(isset($_POST["pic41"]))
	{
		session_start();
		$_SESSION["order"]="pic41";
		header("location:orderform.html");
	}
	if(isset($_POST["pic40"]))
	{
		session_start();
		$_SESSION["order"]="pic40";
		header("location:orderform.html");
	}
	if(isset($_POST["pic39"]))
	{
		session_start();
		$_SESSION["order"]="pic39";
		header("location:orderform.html");
	}
	if(isset($_POST["pic38"]))
	{
		session_start();
		$_SESSION["order"]="pic38";
		header("location:orderform.html");
	}
	if(isset($_POST["pic37"]))
	{
		session_start();
		$_SESSION["order"]="pic37";
		header("location:orderform.html");
	}
	if(isset($_POST["pic36"]))
	{
		session_start();
		$_SESSION["order"]="pic36";
		header("location:orderform.html");
	}
	if(isset($_POST["pic35"]))
	{
		session_start();
		$_SESSION["order"]="pic35";
		header("location:orderform.html");
	}
	if(isset($_POST["pic34"]))
	{
		session_start();
		$_SESSION["order"]="pic34";
		header("location:orderform.html");
	}
	if(isset($_POST["pic33"]))
	{
		session_start();
		$_SESSION["order"]="pic33";
		header("location:orderform.html");
	}
	if(isset($_POST["pic32"]))
	{
		session_start();
		$_SESSION["order"]="pic32";
		header("location:orderform.html");
	}
	if(isset($_POST["pic31"]))
	{
		session_start();
		$_SESSION["order"]="pic31";
		header("location:orderform.html");
	}
	if(isset($_POST["pic30"]))
	{
		session_start();
		$_SESSION["order"]="pic30";
		header("location:orderform.html");
	}
	if(isset($_POST["pic29"]))
	{
		session_start();
		$_SESSION["order"]="pic29";
		header("location:orderform.html");
	}
	if(isset($_POST["pic28"]))
	{
		session_start();
		$_SESSION["order"]="pic28";
		header("location:orderform.html");
	}
	if(isset($_POST["pic27"]))
	{
		session_start();
		$_SESSION["order"]="pic27";
		header("location:orderform.html");
	}
	if(isset($_POST["pic26"]))
	{
		session_start();
		$_SESSION["order"]="pic26";
		header("location:orderform.html");
	}
	if(isset($_POST["pic25"]))
	{
		session_start();
		$_SESSION["order"]="pic25";
		header("location:orderform.html");
	}if(isset($_POST["pic24"]))
	{
		session_start();
		$_SESSION["order"]="pic24";
		header("location:orderform.html");
	}
	if(isset($_POST["pic23"]))
	{
		session_start();
		$_SESSION["order"]="pic23";
		header("location:orderform.html");
	}
	if(isset($_POST["pic22"]))
	{
		session_start();
		$_SESSION["order"]="pic22";
		header("location:orderform.html");
	}
	if(isset($_POST["pic21"]))
	{
		session_start();
		$_SESSION["order"]="pic21";
		header("location:orderform.html");
	}
	if(isset($_POST["pic20"]))
	{
		session_start();
		$_SESSION["order"]="pic20";
		header("location:orderform.html");
	}
	if(isset($_POST["pic19"]))
	{
		session_start();
		$_SESSION["order"]="pic19";
		header("location:orderform.html");
	}
	if(isset($_POST["pic18"]))
	{
		session_start();
		$_SESSION["order"]="pic18";
		header("location:orderform.html");
	}
	if(isset($_POST["pic17"]))
	{
		session_start();
		$_SESSION["order"]="pic17";
		header("location:orderform.html");
	}
	if(isset($_POST["pic16"]))
	{
		session_start();
		$_SESSION["order"]="pic16";
		header("location:orderform.html");
	}if(isset($_POST["pic15"]))
	{
		session_start();
		$_SESSION["order"]="pic15";
		header("location:orderform.html");
	}
	if(isset($_POST["pic14"]))
	{
		session_start();
		$_SESSION["order"]="pic14";
		header("location:orderform.html");
	}
	if(isset($_POST["pic13"]))
	{
		session_start();
		$_SESSION["order"]="pic13";
		header("location:orderform.html");
	}
	if(isset($_POST["pic12"]))
	{
		session_start();
		$_SESSION["order"]="pic12";
		header("location:orderform.html");
	}
	if(isset($_POST["pic11"]))
	{
		session_start();
		$_SESSION["order"]="pic11";
		header("location:orderform.html");
	}
	if(isset($_POST["pic10"]))
	{
		session_start();
		$_SESSION["order"]="pic10";
		header("location:orderform.html");
	}if(isset($_POST["pic9"]))
	{
		session_start();
		$_SESSION["order"]="pic9";
		header("location:orderform.html");
	}
	if(isset($_POST["pic8"]))
	{
		session_start();
		$_SESSION["order"]="pic8";
		header("location:orderform.html");
	}
	if(isset($_POST["pic7"]))
	{
		session_start();
		$_SESSION["order"]="pic7";
		header("location:orderform.html");
	}
	if(isset($_POST["pic6"]))
	{
		session_start();
		$_SESSION["order"]="pic6";
		header("location:orderform.html");
	}
	if(isset($_POST["pic5"]))
	{
		session_start();
		$_SESSION["order"]="pic5";
		header("location:orderform.html");
	}
	if(isset($_POST["pic4"]))
	{
		session_start();
		$_SESSION["order"]="pic4";
		header("location:orderform.html");
	}if(isset($_POST["pic3"]))
	{
		session_start();
		$_SESSION["order"]="pic3";
		header("location:orderform.html");
	}
	if(isset($_POST["pic2"]))
	{
		session_start();
		$_SESSION["order"]="pic2";
		header("location:orderform.html");
	}
	if(isset($_POST["pic1"]))
	{
		session_start();
		$_SESSION["order"]="pic1";
		header("location:orderform.html");
	}
	if(isset($_POST["pic57"]))
	{
		session_start();
		$_SESSION["order"]="pic57";
		header("location:orderform.html");
	}
	if(isset($_POST["pic58"]))
	{
		session_start();
		$_SESSION["order"]="pic58";
		header("location:orderform.html");
	}
	if(isset($_POST["pic59"]))
	{
		session_start();
		$_SESSION["order"]="pic59";
		header("location:orderform.html");
	}
	if(isset($_POST["pic60"]))
	{
		session_start();
		$_SESSION["order"]="pic60";
		header("location:orderform.html");
	}
	if(isset($_POST["pic61"]))
	{
		session_start();
		$_SESSION["order"]="pic61";
		header("location:orderform.html");
	}
	if(isset($_POST["pic62"]))
	{
		session_start();
		$_SESSION["order"]="pic62";
		header("location:orderform.html");
	}
	?>
	<div class="header">	
      <div class="container"> 
  	     <div class="logo">
			<h1><a href="index.html">The quinn</a></h1>
		 </div>
		 <div class="top_right">
		   <ul>
			<li><a href="index.html">Home</a></li>|
			<li><a href="shoes.php">Shoes</a></li>|
			<li><a href="watches.html">Watches</a></li>
		   </ul>
	     </div>
		 <div class="clearfix"></div>
		</div>
	</div>
	<br>
	  <div class="col-md-12 ">	
	       <div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
		   <div class="col-md-12 text-center"><div class="container"><a href="shoes.php" class="btn btn-success" style="width:500px auto;background:#330066">&nbsp&nbsp&nbspAdidas&nbsp&nbsp&nbsp</a><br><br><a href="shoes1.php" class="btn btn-success" style="width:500px auto;background:#330066">&nbsp&nbsp&nbsp&nbsp&nbspNike&nbsp&nbsp&nbsp&nbsp&nbsp</a></div></div>
				<div class="resp-tabs-container">
				   
					 

						<ul class="tab_img">
						   <li>
							 <img src="images/pic51.jpeg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Airmax-2017 <br/>(Green)</p>
								<h4>Price: ₹ 4,099</h4>
								<br/><center><form method="post">
								<a href="pic51.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic51"></form></center>
							 </div>
						   </li>
						   <li>
							 <img src="images/pic52.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Airmax-2017 <br/>(Black)</p>
								<h4>Price: ₹ 4,099</h4>
								<br/><center><form method="post">
								<a href="pic52.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic52"></form></center>
							 </div>
						   </li>
						   <li>
							 <img src="images/pic53.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Airmax-2015 <br/>(Green)</p>
								<h4>Price: ₹ 3,299</h4>
								<br/><center><form method="post">
								<a href="pic53.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic53"></form></center>
							 </div>
						   </li>
						  <li>
							 <img src="images/pic31.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Flyknit Airmax (Purple Blue)</p>
								<h4>Price: ₹ 4,500</h4>
								<br/><center><form method="post">
								<a href="pic31.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic31"></form></center>
							 </div>
						   </li>
							<li>
							 <img src="images/pic32.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Flyknit Airmax (Black White)</p>
								<h4>Price: ₹ 4,500</h4>
								<br/><center><form method="post">
								<a href="pic32.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic32"></form></center>
							 </div>
						   </li>
							<li class="last">
							 <img src="images/pic33.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Superfly Football Studs (Black pink)</p>
								<h4>Price: ₹ 5,299</h4>
								<br/><center><form method="post">
								<a href="pic33.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic33"></form></center>
							 </div>
						   </li>
						 <div class="clearfix"></div>
						</ul>
						<ul class="tab_img">
						    <li>
							 <img src="images/pic34.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike CR7 Superfly Studs (Black Blue)</p>
								<h4>Price: ₹ 6,999</h4>
								<br/><center><form method="post">
								<a href="pic34.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic34"></form></center>
							 </div>
						   </li>
						   <li>
							 <img src="images/pic35.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Hypervenom Football Studs</p>
								<h4>Price: ₹ 6,000</h4>
								<br/><center><form method="post">
								<a href="pic35.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic35"></form></center>
							 </div>
						   </li>
						   <li>
							 <img src="images/pic36.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Huarache <br>(Punch Red)</p>
								<h4>Price: ₹ 3,500</h4>
								<br/><center><form method="post">
								<a href="pic36.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic36"></form></center>
							 </div>
						   </li>
						  <li>
							 <img src="images/pic37.jpeg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Huarache <br><br>(Jet Black)</p>
								<h4>Price: ₹ 3,500</h4>
								<br/><center><form method="post">
								<a href="pic37.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic37"></form></center>
							 </div>
						   </li>
							<li>
							 <img src="images/pic38.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Huarache <br>(White)</p>
								<h4>Price: ₹ 4,000</h4>
								<br/><center><form method="post">
								<a href="pic38.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic38"></form></center>
							 </div>
						   </li>
							<li class="last">
							 <img src="images/pic39.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Inneva <br>(Black)</p>
								<h4>Price: ₹ 3,600</h4>
								<br/><center><form method="post">
								<a href="pic39.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic39"></form></center>
							 </div>
						   </li>
						   <div class="clearfix"></div>
						   </ul>
						   <ul class="tab_img">
						    <li>
							 <img src="images/pic40.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Inneva <br>(Golden)</p>
								<h4>Price: ₹ 3,600</h4>
								<br/><center><form method="post">
								<a href="pic40.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic40"></form></center>
							 </div>
						   </li>
						   <li>
							 <img src="images/pic41.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Inneva <br>(White)</p>
								<h4>Price: ₹ 3,600</h4>
								<br/><center><form method="post">
								<a href="pic41.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic41"></form></center>
							 </div>
						   </li>
						   <li>
							 <img src="images/pic42.jpeg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Le Bron 12 (Cave Purple)</p>
								<h4>Price On Req.</h4>
								<br/><center><form method="post">
								<a href="pic42.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic42"></form></center>
							 </div>
						   </li>
						  <li>
							 <img src="images/pic43.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Le Bron 12 <br/>(Lion Heart)</p>
								<h4>Price On Req.</h4>
								<br/><center><form method="post">
								<a href="pic43.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic43"></form></center>
							 </div>
						   </li>
							<li>
							 <img src="images/pic44.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Le Bron 12 (Orange Green)</p>
								<h4>Price On Req.</h4>
								<br/><center><form method="post">
								<a href="pic44.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic44"></form></center>
							 </div>
						   </li>
							<li class="last">
							 <img src="images/pic45.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Le Bron 12 (Trillion Dollar Edition)</p>
								<h4>Price On Req.</h4>
								<br/><center><form method="post">
								<a href="pic45.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic45"></form></center>
							 </div>
							 </li>
							 <div class="clearfix"></div></ul>
						   <ul class="tab_img">
						    <li>
							 <img src="images/pic46.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Le Bron 12 <br>(Wheat)</p>
								<h4>Price On Req.</h4>
								<br/><center><form method="post">
								<a href="pic46.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic46"></form></center>
							 </div>
						   </li>
						   <li>
							 <img src="images/pic47.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Tavas Airmax <br>(Black)</p>
								<h4>Price: ₹ 3,200</h4>
								<br/><center><form method="post">
								<a href="pic47.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic47"></form></center>
							 </div>
						   </li>
						   <li>
							 <img src="images/pic48.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Tavas Airmax (Grey Bright Crimson)</p>
								<h4>Price: ₹ 3,200</h4>
								<br/><center><form method="post">
								<a href="pic48.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic48"></form></center>
							 </div>
						   </li>
						  <li>
							 <img src="images/pic49.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Tavas Airmax <br>(Red)</p>
								<h4>Price: ₹ 3,200</h4>
								<br/><center><form method="post">
								<a href="pic49.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic49"></form></center>
							 </div>
						   </li>
							<li>
							 <img src="images/pic50.jpg" class="img-responsive" alt=""/>
						     <div class="tab_desc">
								<p>Nike Tavas Airmax (Grey Mist- Flash Lime)</p>
								<h4>Price: ₹ 3,200</h4>
								<br/><center><form method="post">
								<a href="pic50.php" class="btn btn-primary">View</a>
								<input type="submit" class="btn btn-success" value="Order" name="pic50"></form></center>
							 </div>
						   </li>
						   
						   <div class="clearfix"></div>
						</ul>	
</div>						
           </div>
       </div>
       <div class="clearfix"> </div>
    </div>
	</div>
	<div class="grid_3">
	  <div class="container"><div class="col-md-2"><img src="images/delivery.png" ></div><div class="col-md-10"><ul id="footer-links">
			<li><a href="faq.html">FAQs</a></li>
			<li><a href="contact.html">Contact Us</a></li>
         </ul>
         <p>Copyright © 2016 The Quinn. All Rights Reserved.Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a><br><br>Developed By: Akshit Grover & Akash Sharma</p></div>
	  </div>
	</div>
</body>
</html>		